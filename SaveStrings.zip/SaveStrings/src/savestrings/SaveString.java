/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package savestrings;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.json.*;

/**
 *
 * @author vazzoler_simone
 */
public class SaveString {
    
    
    //http://HOST_CATTEDRA/SaveStrings/register.php?username=aaa&password=bbb
    private static void inserisciTappa(String tappa){
        
    }
    
    private static List<Tappe> visualizzaTappe()
    {
        
    }
    
    private static void rimuoviTappe()
    {
        
    }
    
    private static void invertiTappe()
    {
        
    }
    
    private static int calcolaDistanza(){
        
    }
    
    private static void cancellaItinerario(){
        
    }
    
    private static String registraUtente(String username, String password) throws MalformedURLException, IOException{
        
        URL url = new URL("https://savestrings.netsons.org/SaveStrings/register.php?username=" + username + "&password=" + password);
        
        //leggo contenuto url
        String inline = LeggiContenuto(url);
        JSONObject obj = new JSONObject(inline); //lo trasformo in JSONObject
        JSONObject res = (JSONObject) obj.get("status"); //prendo l'oggetto result
        //metto result in una stringa
        String status = res.toString();
        
        if(status.equalsIgnoreCase("ok")){
            return "Complimenti, ti sei registrato su Savestring!";
        }else{
            return "Parametri errati o utente già registrato";
        }
        
    }
    
    private static String LeggiContenuto(URL url) throws IOException{
        
        String inline = "";
        Scanner scanner = new Scanner(url.openStream());
  
        //Write all the JSON data into a string using a scanner
        while (scanner.hasNext()) {
           inline += scanner.nextLine();
        }
        //Close the scanner
        scanner.close();
        return inline;
    }
    
    private static String getToken(String username, String password) throws MalformedURLException, IOException{
        String token = "";
        URL url = new URL("https://savestrings.netsons.org/SaveStrings/getToken.php?username="+ username+ "&pass="+ password);
        
        String inline = LeggiContenuto(url);
        JSONObject obj = new JSONObject(inline);
        //recupero il campo token del json
        JSONObject res = (JSONObject) obj.get("status"); //controllo se lo status è ok
        String status = res.toString();
        
        
        if(status.equalsIgnoreCase("ok")){
            JSONObject res2 = (JSONObject) obj.get("result"); //controllo se lo status è ok
            token = res2.getString("token");
            return token;  
        }else{
            return "Parametri errati!";
        }
       
 
    }
    
    private static String setString(String token, String key, String string) throws MalformedURLException, IOException{
        URL url = new URL("https://savestrings.netsons.org/SaveStrings/setString.php?token="+ token+ "&key="+ key + "&string="+ string);
        
        String inline = LeggiContenuto(url);
        JSONObject obj = new JSONObject(inline);
        //recupero il campo token del json
        JSONObject res = (JSONObject) obj.get("status"); //controllo se lo status è ok
        String status = res.toString();
        
        if(status.equalsIgnoreCase("ok")){
            
            return "Stringa registrata correttamente!";  
        }else{
            return "Token non valido!";
        }
        
        
    }
    
    private static String getString(String token, String key) throws IOException{
        String string ="";
        URL url = new URL("https://savestrings.netsons.org/SaveStrings/getString.php?token="+ token+ "&key="+ key);
        
        String inline = LeggiContenuto(url);
        JSONObject obj = new JSONObject(inline);
        //recupero il campo token del json
        JSONObject res = (JSONObject) obj.get("status"); //controllo se lo status è ok
        String status = res.toString();
        
        if(status.equalsIgnoreCase("ok")){
            JSONObject res2 = (JSONObject) obj.get("result"); 
            string = res2.getString("string");
            
            return string;  
        }else{
            return "Key o token non validi";
        }
  
    }
    
    private static String deleteString(String token, String key) throws MalformedURLException, IOException{
        URL url = new URL("https://savestrings.netsons.org/SaveStrings/deleteString.php?token="+ token+ "&key="+ key);
        
        String inline = LeggiContenuto(url);
        JSONObject obj = new JSONObject(inline);
        //recupero il campo token del json
        JSONObject res = (JSONObject) obj.get("status"); //controllo se lo status è ok
        String status = res.toString();
        
        if(status.equalsIgnoreCase("ok")){
            return "Stringa eliminata correttamente";  
        }else{
            return "Key o token non validi";
        }
    }
    
    private static List<String> getKeys(String token) throws IOException{
        URL url = new URL("https://savestrings.netsons.org/SaveStrings/deleteString.php?token="+ token);
        
        String inline = LeggiContenuto(url);
        JSONObject obj = new JSONObject(inline);
        //recupero il campo token del json
        JSONObject res = (JSONObject) obj.get("status"); //controllo se lo status è ok
        String status = res.toString();
        
        if(status.equalsIgnoreCase("ok")){
            List<String> listaKeys = new ArrayList<String>();
            JSONArray res2 = (JSONArray) obj.get("result");
            //una volta nel result devo scorrere il json array e prendere tutti elementi
            for(int i = 0; i < res.length(); i++)
            {
                
            }
            
              
        }
        return listaKeys;
    }
    
}
